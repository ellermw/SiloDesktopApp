import { useQuery } from "@tanstack/react-query";

import { api } from "@/api/client";
import type {
  CollectionPreviewRequest,
  CollectionPreviewResponse,
  QueryDefinition,
} from "@/api/types";
import { normalizeQueryDefinition } from "@/api/types";

import { collectionKeys } from "./keys";

export function buildCollectionPreviewRequest(
  queryDefinition?: QueryDefinition | null,
  limit = 12,
): CollectionPreviewRequest {
  return {
    query_definition: normalizeQueryDefinition(queryDefinition),
    limit,
  };
}

export function previewFingerprint(
  scope: "user" | "admin",
  request: CollectionPreviewRequest,
): string {
  return JSON.stringify({
    scope,
    limit: request.limit ?? 12,
    query_definition: normalizeQueryDefinition(request.query_definition),
  });
}

function useCollectionPreview(scope: "user" | "admin", request?: CollectionPreviewRequest | null) {
  const normalized = request
    ? buildCollectionPreviewRequest(request.query_definition, request.limit)
    : null;

  return useQuery({
    queryKey: normalized
      ? collectionKeys.preview(scope, previewFingerprint(scope, normalized))
      : collectionKeys.preview(scope, "disabled"),
    queryFn: () =>
      api<CollectionPreviewResponse>(
        scope === "admin" ? "/admin/collections/preview" : "/collections/preview",
        {
          method: "POST",
          body: JSON.stringify(normalized),
        },
      ),
    enabled: normalized !== null,
    staleTime: 30_000,
  });
}

export function useAdminCollectionPreview(request?: CollectionPreviewRequest | null) {
  return useCollectionPreview("admin", request);
}

export function useUserCollectionPreview(request?: CollectionPreviewRequest | null) {
  return useCollectionPreview("user", request);
}
